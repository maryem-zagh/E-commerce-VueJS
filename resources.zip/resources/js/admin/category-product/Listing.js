import AppListing from '../app-components/Listing/AppListing';

Vue.component('category-product-listing', {
    mixins: [AppListing]
});