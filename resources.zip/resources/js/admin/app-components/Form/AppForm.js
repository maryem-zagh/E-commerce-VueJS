import { BaseForm } from 'craftable';

export default {
	mixins: [BaseForm]
};