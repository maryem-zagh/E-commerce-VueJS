import AppListing from '../app-components/Listing/AppListing';

Vue.component('order-listing', {
    mixins: [AppListing]
});