import AppListing from '../app-components/Listing/AppListing';

Vue.component('category-listing', {
    mixins: [AppListing]
});