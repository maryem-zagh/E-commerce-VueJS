<div class="sidebar">
    <nav class="sidebar-nav">
        <ul class="nav">
            <li class="nav-title"><?php echo e(trans('brackets/admin-ui::admin.sidebar.content')); ?></li>
            <li class="nav-item"><a class="nav-link" href="<?php echo e(url('admin/products')); ?>"><i class="nav-icon icon-compass"></i> <?php echo e(trans('admin.product.title')); ?></a></li>
           <li class="nav-item"><a class="nav-link" href="<?php echo e(url('admin/categories')); ?>"><i class="nav-icon icon-diamond"></i> <?php echo e(trans('admin.category.title')); ?></a></li>
           <li class="nav-item"><a class="nav-link" href="<?php echo e(url('admin/category-products')); ?>"><i class="nav-icon icon-plane"></i> <?php echo e(trans('admin.category-product.title')); ?></a></li>
           

            <li class="nav-title"><?php echo e(trans('brackets/admin-ui::admin.sidebar.settings')); ?></li>
            <li class="nav-item"><a class="nav-link" href="<?php echo e(url('admin/admin-users')); ?>"><i class="nav-icon icon-user"></i> <?php echo e(__('Manage access')); ?></a></li>
            <li class="nav-item"><a class="nav-link" href="<?php echo e(url('admin/translations')); ?>"><i class="nav-icon icon-location-pin"></i> <?php echo e(__('Translations')); ?></a></li>
            
            
        </ul>
    </nav>
    <button class="sidebar-minimizer brand-minimizer" type="button"></button>
</div>
<?php /**PATH C:\Users\Thinkpad\Downloads\web\laravel-ecommerce\resources\views/admin/layout/sidebar.blade.php ENDPATH**/ ?>