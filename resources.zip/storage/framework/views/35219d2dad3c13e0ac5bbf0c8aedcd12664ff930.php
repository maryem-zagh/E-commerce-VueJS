import AppListing from '../app-components/Listing/AppListing';

Vue.component('<?php echo e($modelJSName); ?>-listing', {
    mixins: [AppListing]
});<?php /**PATH C:\Users\Thinkpad\Downloads\web\laravel-ecommerce\vendor\brackets\admin-generator\src/../resources/views/listing-js.blade.php ENDPATH**/ ?>