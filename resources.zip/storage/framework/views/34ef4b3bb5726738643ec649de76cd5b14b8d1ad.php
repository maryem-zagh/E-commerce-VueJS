import AppListing from '../app-components/Listing/AppListing';

Vue.component('<?php echo e($modelJSName); ?>-listing', {
    mixins: [AppListing]
});<?php /**PATH C:\xampp8\htdocs\laravel-ecommerce\vendor\brackets\admin-generator\src/../resources/views/listing-js.blade.php ENDPATH**/ ?>