<?php echo e($slot); ?>: <?php echo e($url); ?>

<?php /**PATH C:\Users\Thinkpad\Downloads\web\laravel-ecommerce\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/button.blade.php ENDPATH**/ ?>