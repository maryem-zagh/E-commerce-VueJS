<div class="form-group row align-items-center" :class="{'has-danger': errors.has('title'), 'has-success': fields.title && fields.title.valid }">
    <label for="title" class="col-form-label text-md-right" :class="isFormLocalized ? 'col-md-4' : 'col-md-2'"><?php echo e(trans('admin.product.columns.title')); ?></label>
        <div :class="isFormLocalized ? 'col-md-4' : 'col-md-9 col-xl-8'">
        <input type="text" v-model="form.title" v-validate="'required'" @input="validate($event)" class="form-control" :class="{'form-control-danger': errors.has('title'), 'form-control-success': fields.title && fields.title.valid}" id="title" name="title" placeholder="<?php echo e(trans('admin.product.columns.title')); ?>">
        <div v-if="errors.has('title')" class="form-control-feedback form-text" v-cloak>{{ errors.first('title') }}</div>
    </div>
</div>

<div class="form-group row align-items-center" :class="{'has-danger': errors.has('description'), 'has-success': fields.description && fields.description.valid }">
    <label for="description" class="col-form-label text-md-right" :class="isFormLocalized ? 'col-md-4' : 'col-md-2'"><?php echo e(trans('admin.product.columns.description')); ?></label>
        <div :class="isFormLocalized ? 'col-md-4' : 'col-md-9 col-xl-8'">
        <input type="text" v-model="form.description" v-validate="'required'" @input="validate($event)" class="form-control" :class="{'form-control-danger': errors.has('description'), 'form-control-success': fields.description && fields.description.valid}" id="description" name="description" placeholder="<?php echo e(trans('admin.product.columns.description')); ?>">
        <div v-if="errors.has('description')" class="form-control-feedback form-text" v-cloak>{{ errors.first('description') }}</div>
    </div>
</div>

<div class="form-group row align-items-center" :class="{'has-danger': errors.has('price'), 'has-success': fields.price && fields.price.valid }">
    <label for="price" class="col-form-label text-md-right" :class="isFormLocalized ? 'col-md-4' : 'col-md-2'"><?php echo e(trans('admin.product.columns.price')); ?></label>
        <div :class="isFormLocalized ? 'col-md-4' : 'col-md-9 col-xl-8'">
        <input type="text" v-model="form.price" v-validate="'required|integer'" @input="validate($event)" class="form-control" :class="{'form-control-danger': errors.has('price'), 'form-control-success': fields.price && fields.price.valid}" id="price" name="price" placeholder="<?php echo e(trans('admin.product.columns.price')); ?>">
        <div v-if="errors.has('price')" class="form-control-feedback form-text" v-cloak>{{ errors.first('price') }}</div>
    </div>
</div>

<div class="form-group row align-items-center" :class="{'has-danger': errors.has('slug'), 'has-success': fields.slug && fields.slug.valid }">
    <label for="slug" class="col-form-label text-md-right" :class="isFormLocalized ? 'col-md-4' : 'col-md-2'"><?php echo e(trans('admin.product.columns.slug')); ?></label>
        <div :class="isFormLocalized ? 'col-md-4' : 'col-md-9 col-xl-8'">
        <input type="text" v-model="form.slug" v-validate="'required'" @input="validate($event)" class="form-control" :class="{'form-control-danger': errors.has('slug'), 'form-control-success': fields.slug && fields.slug.valid}" id="slug" name="slug" placeholder="<?php echo e(trans('admin.product.columns.slug')); ?>">
        <div v-if="errors.has('slug')" class="form-control-feedback form-text" v-cloak>{{ errors.first('slug') }}</div>
    </div>
</div>

<div class="form-group row align-items-center" :class="{'has-danger': errors.has('perex'), 'has-success': fields.perex && fields.perex.valid }">
    <label for="perex" class="col-form-label text-md-right" :class="isFormLocalized ? 'col-md-4' : 'col-md-2'"><?php echo e(trans('admin.product.columns.perex')); ?></label>
        <div :class="isFormLocalized ? 'col-md-4' : 'col-md-9 col-xl-8'">
        <input type="text" v-model="form.perex" v-validate="'integer'" @input="validate($event)" class="form-control" :class="{'form-control-danger': errors.has('perex'), 'form-control-success': fields.perex && fields.perex.valid}" id="perex" name="perex" placeholder="<?php echo e(trans('admin.product.columns.perex')); ?>">
        <div v-if="errors.has('perex')" class="form-control-feedback form-text" v-cloak>{{ errors.first('perex') }}</div>
    </div>
</div>


<div class="form-check row" :class="{'has-danger': errors.has('enabled'), 'has-success': fields.enabled && fields.enabled.valid }">
    <div class="ml-md-auto" :class="isFormLocalized ? 'col-md-8' : 'col-md-10'">
        <input class="form-check-input" id="enabled" type="checkbox" v-model="form.enabled" v-validate="''" data-vv-name="enabled"  name="enabled_fake_element">
        <label class="form-check-label" for="enabled">
            <?php echo e(trans('admin.product.columns.enabled')); ?>

        </label>
        <input type="hidden" name="enabled" :value="form.enabled">
        <div v-if="errors.has('enabled')" class="form-control-feedback form-text" v-cloak>{{ errors.first('enabled') }}</div>
    </div>
</div>

<div class="form-group row align-items-center" :class="{'has-danger': errors.has('imageSrc'), 'has-success': fields.imageSrc && fields.imageSrc.valid }">
    <label for="imageSrc" class="col-form-label text-md-right" :class="isFormLocalized ? 'col-md-4' : 'col-md-2'"><?php echo e(trans('admin.product.columns.imageSrc')); ?></label>
        <div :class="isFormLocalized ? 'col-md-4' : 'col-md-9 col-xl-8'">
        <input type="text" v-model="form.imageSrc" v-validate="'required'" @input="validate($event)" class="form-control" :class="{'form-control-danger': errors.has('imageSrc'), 'form-control-success': fields.imageSrc && fields.imageSrc.valid}" id="imageSrc" name="imageSrc" placeholder="<?php echo e(trans('admin.product.columns.imageSrc')); ?>">
        <div v-if="errors.has('imageSrc')" class="form-control-feedback form-text" v-cloak>{{ errors.first('imageSrc') }}</div>
    </div>
</div>

<div class="form-group row align-items-center" :class="{'has-danger': errors.has('imageAlt'), 'has-success': fields.imageAlt && fields.imageAlt.valid }">
    <label for="imageAlt" class="col-form-label text-md-right" :class="isFormLocalized ? 'col-md-4' : 'col-md-2'"><?php echo e(trans('admin.product.columns.imageAlt')); ?></label>
        <div :class="isFormLocalized ? 'col-md-4' : 'col-md-9 col-xl-8'">
        <input type="text" v-model="form.imageAlt" v-validate="'required'" @input="validate($event)" class="form-control" :class="{'form-control-danger': errors.has('imageAlt'), 'form-control-success': fields.imageAlt && fields.imageAlt.valid}" id="imageAlt" name="imageAlt" placeholder="<?php echo e(trans('admin.product.columns.imageAlt')); ?>">
        <div v-if="errors.has('imageAlt')" class="form-control-feedback form-text" v-cloak>{{ errors.first('imageAlt') }}</div>
    </div>
</div>


<?php /**PATH C:\Users\Thinkpad\Downloads\web\laravel-ecommerce\resources\views/admin/product/components/form-elements.blade.php ENDPATH**/ ?>